$(function() {
    $('#btn_submit').click(function (e) {
       //How to send Image from here to backend
   });
});


# Flask
from flask import Flask, flash, render_template, request, url_for, redirect, send_file
from werkzeug.utils import secure_filename

# keras
from keras.preprocessing.image import load_img, img_to_array
from keras.applications.imagenet_utils import preprocess_input, decode_predictions
from keras.models import load_model
from keras.preprocessing import image
from keras.applications.mobilenet import preprocess_input
#from keras.models import model_from_json

from tensorflow.keras.models import model_from_json

import os
import json
import numpy as np
import matplotlib.pyplot as plt

model_weights = 'MobileNet.h5'
model_json = 'cat1.json'
#model_json = 'cat_to_name.json'


coin_dict = {
    0: "1 Cent,Australian dollar,australia",
    1: "2 Cents,Australian dollar,australia",
    2: "5 Cents,Australian dollar,australia",
    3: "10 Cents,Australian dollar,australia",
    4: "20 Cents,Australian dollar,australia",
    5: "50 Cents,Australian dollar,australia",
    6: "1 Dollar,Australian dollar,australia",
    7: "2 Dollars,Australian dollar,australia",
    8: "1 Centavo,Brazilian Real,brazil",
    9: "5 Centavos,Brazilian Real,brazil",
    10: "10 Centavos,Brazilian Real,brazil",
    11: "25 Centavos,Brazilian Real,brazil",
    12: "1 Real,Brazilian Real,brazil",
    13: "1 Penny,British Pound,united_kingdom",
    14: "2 Pence,British Pound,united_kingdom",
    15: "5 Pence,British Pound,united_kingdom",
    16: "10 Pence,British Pound,united_kingdom",
    17: "20 Pence,British Pound,united_kingdom",
    18: "50 Pence,British Pound,united_kingdom",
    19: "1 Pound,British Pound,united_kingdom",
    20: "2 Pounds,British Pound,united_kingdom",
    21: "1 Cent,Canadian Dollar,canada",
    22: "5 Cents,Canadian Dollar,canada",
    23: "10 Cents,Canadian Dollar,canada",
    24: "25 Cents,Canadian Dollar,canada",
    25: "50 Cents,Canadian Dollar,canada",
    26: "1 Dollar,Canadian Dollar,canada",
    27: "2 Dollars,Canadian Dollar,canada",
    28: "1 Peso,Chilean Peso,chile",
    29: "5 Pesos,Chilean Peso,chile",
    30: "10 Pesos,Chilean Peso,chile",
    31: "50 Pesos,Chilean Peso,chile",
    32: "100 Pesos,Chilean Peso,chile",
    33: "500 Pesos,Chilean Peso,chile",
    34: "1 Jiao,Chinese Yuan Renminbi,china",
    35: "5 Jiao,Chinese Yuan Renminbi,china",
    36: "1 Yuan,Chinese Yuan Renminbi,china",
    37: "10 Hellers,Czech Koruna,czech_republic",
    38: "20 Hellers,Czech Koruna,czech_republic",
    39: "50 Hellers,Czech Koruna,czech_republic",
    40: "1 Koruna,Czech Koruna,czech_republic",
    41: "2 Koruny,Czech Koruna,czech_republic",
    42: "5 Korun,Czech Koruna,czech_republic",
    43: "10 Korun,Czech Koruna,czech_republic",
    44: "20 Korun,Czech Koruna,czech_republic",
    45: "50 Korun,Czech Koruna,czech_republic",
    46: "25 Ore,Danish Krone,denmark",
    47: "50 Ore,Danish Krone,denmark",
    48: "1 Krone,Danish Krone,denmark",
    49: "2 Kroner,Danish Krone,denmark",
    50: "5 Kroner,Danish Krone,denmark",
    51: "10 Kroner,Danish Krone,denmark",
    52: "20 Kroner,Danish Krone,denmark",
    53: "1 euro Cent,Euro,spain",
    54: "2 euro Cent,Euro,spain",
    55: "5 euro Cent,Euro,spain",
    56: "10 euro Cent,Euro,spain",
    57: "20 euro Cent,Euro,spain",
    58: "50 euro Cent,Euro,spain",
    59: "1 Euro,Euro,spain",
    60: "2 Euro,Euro,spain",
    61: "10 Cents,Hong Kong dollar,hong_kong",
    62: "50 Cents,Hong Kong dollar,hong_kong",
    63: "1 Dollar,Hong Kong dollar,hong_kong",
    64: "2 Dollars,Hong Kong dollar,hong_kong",
    65: "5 Dollars,Hong Kong dollar,hong_kong",
    66: "1 Forint,Hungarian Forint,hungary",
    67: "2 Forint,Hungarian Forint,hungary",
    68: "5 Forint,Hungarian Forint,hungary",
    69: "10 Forint,Hungarian Forint,hungary",
    70: "20 Forint,Hungarian Forint,hungary",
    71: "50 Forint,Hungarian Forint,hungary",
    72: "100 Forint,Hungarian Forint,hungary",
    73: "200 Forint,Hungarian Forint,hungary",
    74: "25 Paise,Indian Rupee,india",
    75: "50 Paise,Indian Rupee,india",
    76: "1 Rupee,Indian Rupee,india",
    77: "2 Rupees,Indian Rupee,india",
    78: "5 Rupees,Indian Rupee,india",
    79: "10 Rupees,Indian Rupee,india",
    80: "50 Rupiah,Indonesian Rupiah,indonesia",
    81: "100 Rupiah,Indonesian Rupiah,indonesia",
    82: "200 Rupiah,Indonesian Rupiah,indonesia",
    83: "500 Rupiah,Indonesian Rupiah,indonesia",
    84: "1000 Rupiah,Indonesian Rupiah,indonesia",
    85: "5 Agorot,Israeli New Shekel,israel",
    86: "10 Agorot,Israeli New Shekel,israel",
    87: "1 2 New Sheqel,Israeli New Shekel,israel",
    88: "1 New Sheqel,Israeli New Shekel,israel",
    89: "2 New Sheqalim,Israeli New Shekel,israel",
    90: "5 New Sheqalim,Israeli New Shekel,israel",
    91: "10 New Sheqalim,Israeli New Shekel,israel",
    92: "1 Yen,Japanese Yen,japan",
    93: "5 Yen,Japanese Yen,japan",
    94: "10 Yen,Japanese Yen,japan",
    95: "50 Yen,Japanese Yen,japan",
    96: "100 Yen,Japanese Yen,japan",
    97: "500 Yen,Japanese Yen,japan",
    98: "1 Won,Korean Won,south_korea",
    99: "5 Won,Korean Won,south_korea",
    100: "10 Won,Korean Won,south_korea",
    101: "50 Won,Korean Won,south_korea",
    102: "100 Won,Korean Won,south_korea",
    103: "500 Won,Korean Won,south_korea",
    104: "1 Sen,Malaysian Ringgit,malaysia",
    105: "5 Sen,Malaysian Ringgit,malaysia",
    106: "10 Sen,Malaysian Ringgit,malaysia",
    107: "20 Sen,Malaysian Ringgit,malaysia",
    108: "50 Sen,Malaysian Ringgit,malaysia",
    109: "5 Centavos,Mexican peso,mexico",
    110: "10 Centavos,Mexican peso,mexico",
    111: "20 Centavos,Mexican peso,mexico",
    112: "50 Centavos,Mexican peso,mexico",
    113: "1 Peso,Mexican peso,mexico",
    114: "2 Pesos,Mexican peso,mexico",
    115: "5 Pesos,Mexican peso,mexico",
    116: "10 Pesos,Mexican peso,mexico",
    117: "5 Cents,New Zealand dollar,new_zealand",
    118: "10 Cents,New Zealand dollar,new_zealand",
    119: "20 Cents,New Zealand dollar,new_zealand",
    120: "50 Cents,New Zealand dollar,new_zealand",
    121: "1 Dollar,New Zealand dollar,new_zealand",
    122: "2 Dollars,New Zealand dollar,new_zealand",
    123: "50 Ore,Norwegian Krone,norway",
    124: "1 Krone,Norwegian Krone,norway",
    125: "5 Kroner,Norwegian Krone,norway",
    126: "10 Kroner,Norwegian Krone,norway",
    127: "20 Kroner,Norwegian Krone,norway",
    128: "1 Rupee,Pakistan Rupee,pakistan",
    129: "2 Rupees,Pakistan Rupee,pakistan",
    130: "5 Rupees,Pakistan Rupee,pakistan",
    131: "10 Rupees,Pakistan Rupee,pakistan",
    132: "1 Sentimo,Philipine peso,philippines",
    133: "5 Sentimos,Philipine peso,philippines",
    134: "10 Sentimos,Philipine peso,philippines",
    135: "25 Sentimos,Philipine peso,philippines",
    136: "1 Piso,Philipine peso,philippines",
    137: "5 Piso,Philipine peso,philippines",
    138: "10 Piso,Philipine peso,philippines",
    139: "1 Grosz,Polish Zloty,poland",
    140: "2 Grosze,Polish Zloty,poland",
    141: "5 Groszy,Polish Zloty,poland",
    142: "10 Groszy,Polish Zloty,poland",
    143: "20 Groszy,Polish Zloty,poland",
    144: "50 Groszy,Polish Zloty,poland",
    145: "1 Zloty,Polish Zloty,poland",
    146: "2 Zlote,Polish Zloty,poland",
    147: "5 Zlotych,Polish Zloty,poland",
    148: "1 Kopek,Russian Ruble,russia",
    149: "5 Kopeks,Russian Ruble,russia",
    150: "10 Kopeks,Russian Ruble,russia",
    151: "50 Kopeks,Russian Ruble,russia",
    152: "1 Ruble,Russian Ruble,russia",
    153: "2 Rubles,Russian Ruble,russia",
    154: "5 Rubles,Russian Ruble,russia",
    155: "10 Rubles,Russian Ruble,russia",
    156: "1 Cent,Singapore Dollar,singapore",
    157: "5 Cents,Singapore Dollar,singapore",
    158: "10 Cents,Singapore Dollar,singapore",
    159: "20 Cents,Singapore Dollar,singapore",
    160: "50 Cents,Singapore Dollar,singapore",
    161: "1 Dollar,Singapore Dollar,singapore",
    162: "5 Dollars,Singapore Dollar,singapore",
    163: "5 Cents,South African Rand,south_africa",
    164: "10 Cents,South African Rand,south_africa",
    165: "20 Cents,South African Rand,south_africa",
    166: "50 Cents,South African Rand,south_africa",
    167: "1 Rand,South African Rand,south_africa",
    168: "2 Rand,South African Rand,south_africa",
    169: "5 Rand,South African Rand,south_africa",
    170: "10 Ore,Swedish Krona,sweden",
    171: "50 Ore,Swedish Krona,sweden",
    172: "1 Krona,Swedish Krona,sweden",
    173: "2 Kronor,Swedish Krona,sweden",
    174: "5 Kronor,Swedish Krona,sweden",
    175: "10 Kronor,Swedish Krona,sweden",
    176: "1 Rappen,Swiss Franc,switzerland",
    177: "5 Rappen,Swiss Franc,switzerland",
    178: "10 Rappen,Swiss Franc,switzerland",
    179: "20 Rappen,Swiss Franc,switzerland",
    180: "1 2 Franc,Swiss Franc,switzerland",
    181: "1 Franc,Swiss Franc,switzerland",
    182: "2 Francs,Swiss Franc,switzerland",
    183: "5 Francs,Swiss Franc,switzerland",
    184: "1 2 Dollar,taiwan Dollar,taiwan",
    185: "1 Dollar,taiwan Dollar,taiwan",
    186: "5 Dollars,taiwan Dollar,taiwan",
    187: "10 Dollars,taiwan Dollar,taiwan",
    188: "20 Dollars,taiwan Dollar,taiwan",
    189: "50 Dollars,taiwan Dollar,taiwan",
    190: "1 Satang,Thai Baht,thailand",
    191: "5 Satang,Thai Baht,thailand",
    192: "10 Satang,Thai Baht,thailand",
    193: "25 Satang,Thai Baht,thailand",
    194: "50 Satang,Thai Baht,thailand",
    195: "1 Baht,Thai Baht,thailand",
    196: "2 Baht,Thai Baht,thailand",
    197: "5 Baht,Thai Baht,thailand",
    198: "10 Baht,Thai Baht,thailand",
    199: "1 Kurus,Turkish Lira,turkey",
    200: "5 Kurus,Turkish Lira,turkey",
    201: "10 Kurus,Turkish Lira,turkey",
    202: "25 Kurus,Turkish Lira,turkey",
    203: "50 Kurus,Turkish Lira,turkey",
    204: "1 Lira,Turkish Lira,turkey",
    205: "1 Cent,US Dollar,usa",
    206: "5 Cents,US Dollar,usa",
    207: "1 Dime,US Dollar,usa",
    208: "1 4 Dollar,US Dollar,usa",
    209: "1 2 Dollar,US Dollar,usa",
    210: "1 Dollar,US Dollar,usa"
}

with open(model_json) as json_file:
    model = model_from_json(json_file.read())
    model.load_weights(model_weights)

def model_predict(img_path):
    ukuran = (224,224)
    gbr = load_img(img_path,target_size=ukuran)
    gbr = image.img_to_array(gbr).astype('float32')/255
    
    mean = [0.485, 0.456, 0.406]
    std = [0.229, 0.224, 0.225]
    gbr = (gbr - mean)/std
    
    gbr = np.array(gbr)
    img_expand = np.expand_dims(gbr, axis=0)
        
    prediction = model.predict(img_expand)
    lokasi_tertinggi = np.argmax(prediction[0])
    nilainya = prediction[0][lokasi_tertinggi]
    return lokasi_tertinggi,nilainya

app = Flask(__name__ )



@app.route("/", methods =['GET'])
def home():
    return render_template("web.html")

@app.route('/predict', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        f = request.files['file']
        f.save(f.filename)
        asal,nilai = model_predict(f.filename)
        os.remove(f.filename)
        hasil_total = coin_dict[asal]
        nilai = str(nilai)
        hasil_total=hasil_total+'!'+nilai
    return hasil_total
        
        
if __name__ == '__main__':
    app.run(debug=True)


